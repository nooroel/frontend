var currentPage = document.querySelector('nav ul li:nth-of-type(1) a');
currentPage.classList.add('activeLink');